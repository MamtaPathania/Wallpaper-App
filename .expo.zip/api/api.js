// const baseUrl='http://localhost:4080';
// const baseUrl='http://192.168.1.16:4080';
const baseUrl=`https://imageuploader.visiontrek.io`

const GetUploadImage = `${baseUrl}/getupload-img`
export { GetUploadImage };

const CategoryData=`${baseUrl}/getupload-img/category`
export {CategoryData};

const SaveDownloadedImage=`${baseUrl}/getupload-img/downloads`
export {SaveDownloadedImage}

const DistinctCategory=`${baseUrl}/getupload-img/fetch-categories`
export {DistinctCategory}




